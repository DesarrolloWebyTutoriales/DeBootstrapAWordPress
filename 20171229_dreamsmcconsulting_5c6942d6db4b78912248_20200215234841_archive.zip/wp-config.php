<?php
/** 
 * Configuración básica de WordPress.
 *
 * Este archivo contiene las siguientes configuraciones: ajustes de MySQL, prefijo de tablas,
 * claves secretas, idioma de WordPress y ABSPATH. Para obtener más información,
 * visita la página del Codex{@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} . Los ajustes de MySQL te los proporcionará tu proveedor de alojamiento web.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** Ajustes de MySQL. Solicita estos datos a tu proveedor de alojamiento web. ** //
/** El nombre de tu base de datos de WordPress */
define('DB_NAME', '');

/** Tu nombre de usuario de MySQL */
define('DB_USER', '');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', '');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', '');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');

/** Cotejamiento de la base de datos. No lo modifiques si tienes dudas. */
define('DB_COLLATE', '');

/**#@+
 * Claves únicas de autentificación.
 *
 * Define cada clave secreta con una frase aleatoria distinta.
 * Puedes generarlas usando el {@link https://api.wordpress.org/secret-key/1.1/salt/ servicio de claves secretas de WordPress}
 * Puedes cambiar las claves en cualquier momento para invalidar todas las cookies existentes. Esto forzará a todos los usuarios a volver a hacer login.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'D{$=xj,%,@/qYO=:*uw+J+X,Dp6:&;@iQ4+JyV|kd)c0Aac?E%cU(B7!6XT8k8Z~');
define('SECURE_AUTH_KEY',  'l8!Ynw2U6-/wX6L_-v.ks5Uv=wxzW+)I:@K(/P^$nJu{D2. Ae8+(4Cq&I)m-w-Y');
define('LOGGED_IN_KEY',    ';O+CEVtz+1ds7FBwN[!umIC=-X!e7Z?OMs^Bb@R]l9(+cvg}zJD=)+Vz.|&M2eoz');
define('NONCE_KEY',        '.YCqc+as7kI_6(R1p]O)t&ZItok-g&?>.nJRZtj$CG{$f@81hJ4`;bWq*b|r.ZB8');
define('AUTH_SALT',        '[$F;M7*s.fZSGi<sXfC/]++RO]3+*8t4sU1p-0]e_oOiV=(FhG4F|( i9d8k+N1P');
define('SECURE_AUTH_SALT', 'C*@0_}gx#2xQbQxq/U1^,)i}B:2-H3,w-ZH%U&qooN@}vK%QvR:r_4)7?qqidhEj');
define('LOGGED_IN_SALT',   '[oJP$3Q-}bhBk<mxEw|S7c1=Qf6M:k(SYeWw(6xv`,q1|r<KKkR!uOl$rE~#hfe`');
define('NONCE_SALT',       'SUV+4IY$7WZ*vl.fw_53d*Q#+lQGv?8/;)+IR+hXiJ+9Iz_TNa%S][NOd64E9?7g');

/**#@-*/

/**
 * Prefijo de la base de datos de WordPress.
 *
 * Cambia el prefijo si deseas instalar multiples blogs en una sola base de datos.
 * Emplea solo números, letras y guión bajo.
 */
$table_prefix  = 'wp_';


/**
 * Para desarrolladores: modo debug de WordPress.
 *
 * Cambia esto a true para activar la muestra de avisos durante el desarrollo.
 * Se recomienda encarecidamente a los desarrolladores de temas y plugins que usen WP_DEBUG
 * en sus entornos de desarrollo.
 */
define('WP_DEBUG', false);

/* ¡Eso es todo, deja de editar! Feliz blogging */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');